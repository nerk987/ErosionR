bl_info = {
    "name": "ErosionR",
    "author": "Michel Anders (varkenvarken), Ian Huish (nerk)",
    "version": (0, 1, 0),
    "blender": (2, 72, 0),
    "location": "View3D > Object > ErodeR, View3D > Paint_Weight > ErodeR",
    "description": "Apply various kinds of erosion to a mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Mesh"}

from random import random as rand
from math import tan, radians
from .eroder import Grid
#print("Imported multifiles", file=sys.stderr)
import bpy
from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty, StringProperty    
from .stats import Stats
from .utils import numexpr_available

def availableVertexGroupsOrNone(self, context):
    groups = [ ('None', 'None', 'None', 1) ]
    return groups + [(name, name, name, n+1) for n,name in enumerate(context.active_object.vertex_groups.keys())]
    
class Eroder(bpy.types.Operator):
    bl_idname = "mesh.eroder"
    bl_label = "Eroder"
    bl_options = {'REGISTER', 'UNDO', 'PRESET'}

    Iterations = IntProperty(name="Iterations", description="Number of overall iterations", default=1, min=0, soft_max=100)
    IterRiver = IntProperty(name="River Iterations", description="Number of river iterations", default=30, min=0, soft_max=1000)
    IterAva = IntProperty(name="Avalanche Iterations", description="Number of avalanche iterations", default=5, min=0, soft_max=10)
    IterDiffuse = IntProperty(name="Diffuse Iterations", description="Number of diffuse iterations", default=5, min=0, soft_max=10)
    
    Ef = FloatProperty(name="Rain on Plains", description="1 gives equal rain across the terrain, 0 rains more at the mountain tops", default=0.0, min=0, max=1)
    Kd = FloatProperty(name="Kd", description="Thermal diffusion rate (1.0 is a fairly high rate)", default=0.1, min=0, soft_max=100)

    Kt = FloatProperty(name="Kt", description="Maximum stable talus angle", default=radians(60), min=0, max=radians(90), subtype='ANGLE')

    Kr   = FloatProperty(name="Rain amount"      , description="Total Rain amount                          ", default=.01   , min=0, soft_max=1)
    Kv   = FloatProperty(name="Rain variance"    , description="Rain variance (0 is constant, 1 is uniform)", default=0   , min=0, max=1)
    userainmap = BoolProperty(name="Use rain map", description="Use active vertex group as a rain map"      , default=True)
    
    Ks   = FloatProperty(name="Soil solubility"  , description="Soil solubility - how quickly water quickly reaches saturation point", default=0.5, min=0, soft_max=1)
    Kdep = FloatProperty(name="Deposition rate"  , description="Sediment deposition rate - how quickly silt is laid down once water stops flowing quickly"                   , default=0.1, min=0, soft_max=1)
    Kz = FloatProperty(name="Fluvial Erosion Rate"  , description="Amount of sediment moved each main iteration - if 0, then rivers are formed but the mesh is not changed"  , default=0.3, min=0, soft_max=20)
    Kc   = FloatProperty(name="Carrying capacity", description="Base sediment carrying capacity"            , default=0.9 , min=0, soft_max=1)
    Ka   = FloatProperty(name="Slope dependence" , description="Slope dependence of carrying capacity (not used)"      , default=1.0 , min=0, soft_max=2)
    Kev   = FloatProperty(name="Evaporation" , description="Evaporation Rate per grid square in % - causes sediment to be dropped closer to the hills"      , default=.5 , min=0, soft_max=2)

    numexpr = BoolProperty(name="Numexpr", description="Use numexpr module (if available)", default=True)

    Pd = FloatProperty(name="Diffusion Amount", description="Diffusion probability"    , default=0.2, min=0, max=1)
    Pa = FloatProperty(name="Avalanche Amount", description="Avalanche amount"    , default=0.5, min=0, max=1)
    Pw = FloatProperty(name="River Amount", description="Water erosion probability", default=1  , min=0, max=1)
    
    smooth = BoolProperty(name="Smooth", description="Set smooth shading", default=True)

    showiterstats = BoolProperty(name="Iteration Stats", description="Show iteraration statistics", default=False)
    showmeshstats = BoolProperty(name="Mesh Stats"     , description="Show mesh statistics"       , default=False)

    stats = Stats()
    counts= {}

    # add poll function to restrict action to mesh object in object mode
    
    def execute(self, context):
        ob = context.active_object
        #obwater = bpy.data.objects["water"]
        me = ob.data
        #mewater = obwater.data
        self.stats.reset()
        try:
            vgActive = ob.vertex_groups.active.name
        except:
            vgActive = "capacity"
        print("ActiveGroup", vgActive)
        try:
            vg=ob.vertex_groups["rainmap"]
        except:
            vg=ob.vertex_groups.new("rainmap")
        try:
            vgscree=ob.vertex_groups["scree"]
        except:
            vgscree=ob.vertex_groups.new("scree")
        try:
            vgavalanced=ob.vertex_groups["avalanced"]
        except:
            vgavalanced=ob.vertex_groups.new("avalanced")
        try:
            vgw=ob.vertex_groups["water"]
        except:
            vgw=ob.vertex_groups.new("water")
        try:
            vgscour=ob.vertex_groups["scour"]
        except:
            vgscour=ob.vertex_groups.new("scour")
        try:
            vgdeposit=ob.vertex_groups["deposit"]
        except:
            vgdeposit=ob.vertex_groups.new("deposit")
        try:
            vgflowrate=ob.vertex_groups["flowrate"]
        except:
            vgflowrate=ob.vertex_groups.new("flowrate")
        try:
            vgsediment=ob.vertex_groups["sediment"]
        except:
            vgsediment=ob.vertex_groups.new("sediment")
        try:
            vgsedimentpct=ob.vertex_groups["sedimentpct"]
        except:
            vgsedimentpct=ob.vertex_groups.new("sedimentpct")
        try:
            vgcapacity=ob.vertex_groups["capacity"]
        except:
            vgcapacity=ob.vertex_groups.new("capacity")
        g = Grid.fromBlenderMesh(me, vg, self.Ef)
            
        me = bpy.data.meshes.new(me.name)
        #mewater = bpy.data.meshes.new(mewater.name)

        self.counts['diffuse']=0
        self.counts['avalanche']=0
        self.counts['water']=0
        for i in range(self.Iterations):
            if self.IterRiver > 0:
                for i in range(self.IterRiver):
                    g.rivergeneration(self.Kr, self.Kv, self.userainmap, self.Kc, self.Ks, self.Kdep, self.Ka, self.Kev/100, 0,0,0,0, self.numexpr)
            
            if self.Kd > 0.0:
                for k in range(self.IterDiffuse):
                    g.diffuse(self.Kd / 5, self.IterDiffuse, self.numexpr)
                    self.counts['diffuse']+=1
            #if self.Kt < radians(90) and rand() < self.Pa:
            if self.Kt < radians(90) and self.Pa > 0:
                for k in range(self.IterAva):
# since dx and dy are scaled to 1, tan(Kt) is the height for a given angle
                    g.avalanche(tan(self.Kt), self.IterAva, self.Pa, self.numexpr)
                    self.counts['avalanche']+=1
            if self.Kz > 0:
                g.fluvial_erosion(self.Kr, self.Kv, self.userainmap, self.Kc, self.Ks, self.Kz*50, self.Ka, 0,0,0,0, self.numexpr)
                self.counts['water']+=1

        g.toBlenderMesh(me)
        ob.data = me
        #g.toWaterMesh(mewater)
        #obwater.data = mewater
        if vg:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vg.add([i],g.rainmap[row,col],'ADD')
        if vgscree:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgscree.add([i],g.avalanced[row,col],'ADD')
        if vgavalanced:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgavalanced.add([i],-g.avalanced[row,col],'ADD')
        if vgw:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgw.add([i],g.water[row,col]/g.watermax,'ADD')
                    #vgw.add([i],g.water[row,col],'ADD')
        if vgscour:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
#                    vgscour.add([i],(g.scour[row,col]-g.scourmin)/(g.scourmax-g.scourmin),'ADD')
                    vgscour.add([i],g.scour[row,col]/max(g.scourmax, -g.scourmin),'ADD')
        if vgdeposit:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgdeposit.add([i],g.scour[row,col]/min(-g.scourmax, g.scourmin),'ADD')
        if vgflowrate:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    #vgflowrate.add([i],g.flowrate[row,col]/g.flowratemax,'ADD')
                    vgflowrate.add([i],g.flowrate[row,col],'ADD')
        if vgsediment:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    #vgsediment.add([i],g.sediment[row,col]/g.sedmax,'ADD')
                    vgsediment.add([i],g.sediment[row,col],'ADD')
        if vgsedimentpct:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgsedimentpct.add([i],g.sedimentpct[row,col],'ADD')
        if vgcapacity:
            for row in range(g.rainmap.shape[0]):
                for col in range(g.rainmap.shape[1]):
                    i = row * g.rainmap.shape[1] + col
                    vgcapacity.add([i],g.capacity[row,col],'ADD')
        try:
            vg = ob.vertex_groups["vgActive"]
        except:
            vg = vgcapacity
        ob.vertex_groups.active = vg
            
        if self.smooth:
            bpy.ops.object.shade_smooth()
        self.stats.time()
        self.stats.memory()
        if self.showmeshstats:
            self.stats.meshstats = g.analyze()
            
        return {'FINISHED'}
    
    def draw(self,context):
        layout = self.layout

        layout.operator('screen.repeat_last', text="Repeat", icon='FILE_REFRESH' )

        layout.prop(self, 'Iterations')
        
        box = layout.box()
        box.label("Thermal (Diffusion)")
        box.prop(self, 'Kd')
        box.prop(self, 'IterDiffuse')

        box = layout.box()
        box.label("Avalanche (Talus)")
        box.prop(self, 'Pa')
        box.prop(self, 'IterAva')
        box.prop(self, 'Kt')
       
        box = layout.box()
        box.label("River erosion")
        box.prop(self, 'IterRiver')
        box.prop(self, 'Kz')
        box.prop(self, 'Ks')
        box.prop(self, 'Kc')
        box.prop(self, 'Kdep')
        box.prop(self, 'Kr')
        box.prop(self, 'Kv')
        box.prop(self, 'Kev')
        #box2 = box.box()
        #box2.prop(self, 'userainmap')
        #box2.enabled = context.active_object.vertex_groups.active is not None
        #box.prop(self, 'Ka')
        box.prop(self, 'Ef')
        
        #box = layout.box()
        #box.label("Probabilities")
        #box.prop(self, 'Pa')
        #box.prop(self, 'Pw')
        
        layout.prop(self,'smooth')
        
        #if numexpr_available:
        #  layout.prop(self, 'numexpr')
        #else:
        #  box = layout.box()
        #  box.alert=True
        #  box.label("Numexpr not available. Will slow down large meshes")

        #box = layout.box()
        #box.prop(self,'showiterstats')
        #if self.showiterstats:
        #    row = box.row()
        #    col1 = row.column()
        #    col2 = row.column()
        #    col1.label("Time"); col2.label("%.1f s"%self.stats.elapsedtime)
        #    if self.stats.memstats_available:
        #        col1.label("Memory"); col2.label("%.1f Mb"%(self.stats.maxmem/(1024.0*1024.0)))
        #    col1.label("Diffusions"); col2.label("%d"% self.counts['diffuse'])
        #    col1.label("Avalanches"); col2.label("%d"% self.counts['avalanche'])
        #    col1.label("Water movements"); col2.label("%d"% self.counts['water'])
        #box = layout.box()
        #box.prop(self,'showmeshstats')
        #if self.showmeshstats:
        #    row = box.row()
        #    col1 = row.column()
        #    col2 = row.column()
        #    for line in self.stats.meshstats.split('\n'):
        #        label, value = line.split(':')
        #        col1.label(label)
        #        col2.label(value)

def menu_func_eroder(self, context):
    self.layout.operator(Eroder.bl_idname, text="Eroder",
                         icon='RNDCURVE')

def register():
    bpy.utils.register_class(Eroder)
    bpy.types.VIEW3D_MT_paint_weight.append(menu_func_eroder)
    bpy.types.VIEW3D_MT_object.append(menu_func_eroder)


def unregister():
    bpy.types.VIEW3D_MT_paint_weight.remove(menu_func_eroder)
    bpy.types.VIEW3D_MT_object.remove(menu_func_eroder)
    bpy.utils.unregister_class(Eroder)